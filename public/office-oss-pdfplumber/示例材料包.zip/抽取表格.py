import csv, sys
from pathlib import Path
import pdfplumber

source, target = map(Path, sys.argv[1:3])
with pdfplumber.open(source) as pdf:
    if len(pdf.pages) != 1:
        raise SystemExit("本示例脚本仅处理单页PDF，请先确认页数")
    page = pdf.pages[0]
    table = page.extract_table()
    print(f"pages=1 chars={len(page.chars)} images={len(page.images)}")
    if not table:
        print("未找到可抽取的表格；没有写入CSV。先检查是否为纯图片或版面不适用。", file=sys.stderr)
        raise SystemExit(2)
    with target.open("w", encoding="utf-8-sig", newline="") as f:
        csv.writer(f).writerows(table)
    print(f"rows_with_header={len(table)} columns={len(table[0])}")
    print(f"csv={target.name}")
